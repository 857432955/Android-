package com.lljjcoder.citypickerview.widget;

/**
 * 作者：liji on 2016/6/30 14:58
 * 邮箱：lijiwork@sina.com
 */
public interface CanShow {
    void setType(int var1);

    void show();

    void hide();

    boolean isShow();
}
